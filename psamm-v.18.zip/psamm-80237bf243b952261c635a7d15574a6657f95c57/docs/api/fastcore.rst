
``psamm.fastcore`` -- Fastcore (approximate consistent subset)
===============================================================

.. automodule:: psamm.fastcore
   :members:
