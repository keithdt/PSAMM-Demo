
``psamm.expression.boolean`` -- Boolean expressions
====================================================

.. automodule:: psamm.expression.boolean
   :members:
