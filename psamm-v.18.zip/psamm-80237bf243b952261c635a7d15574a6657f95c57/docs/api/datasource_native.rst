
``psamm.datasource.native`` -- Native data format parser
=========================================================

.. automodule:: psamm.datasource.native
   :members:
