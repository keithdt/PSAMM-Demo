
``psamm.lpsolver.qsoptex`` -- QSopt_ex LP solver
=================================================

.. automodule:: psamm.lpsolver.qsoptex
   :members:
