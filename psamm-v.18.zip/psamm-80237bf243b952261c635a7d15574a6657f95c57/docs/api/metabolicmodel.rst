
``psamm.metabolicmodel`` -- Metabolic model representation
===========================================================

.. automodule:: psamm.metabolicmodel
   :members:
