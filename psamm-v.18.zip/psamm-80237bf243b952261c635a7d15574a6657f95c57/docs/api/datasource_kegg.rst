
``psamm.datasource.kegg`` -- KEGG data parser
==============================================

.. automodule:: psamm.datasource.kegg
   :members:
