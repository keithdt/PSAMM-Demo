
``psamm.datasource.modelseed`` -- ModelSEED data parser
========================================================

.. automodule:: psamm.datasource.modelseed
   :members:
