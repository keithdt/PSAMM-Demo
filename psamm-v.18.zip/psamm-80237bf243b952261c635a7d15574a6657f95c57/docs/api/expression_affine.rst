
``psamm.expression.affine`` -- Affine expressions
==================================================

.. automodule:: psamm.expression.affine
   :members:
